///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//  Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>
#include <iostream>

// globals used by shader
namespace
{
    const char* g_ModelName = "model";
    const char* g_ColorValueName = "objectColor";
    const char* g_TextureValueName = "objectTexture";
    const char* g_UseTextureName = "bUseTexture";
    const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
    m_pShaderManager = pShaderManager;
    m_basicMeshes = new ShapeMeshes();

    for (int i = 0; i < 16; i++)
    {
        m_textureIDs[i].tag = "/0";
        m_textureIDs[i].ID = 0;
    }
    m_loadedTextures = 0;
}

/***********************************************************
 *  ~SceneManager()
 ***********************************************************/
SceneManager::~SceneManager()
{
    m_pShaderManager = NULL;

    if (m_basicMeshes != NULL)
    {
        delete m_basicMeshes;
        m_basicMeshes = NULL;
    }

    DestroyGLTextures();
    m_objectMaterials.clear();
}

/***********************************************************
 *  CreateGLTexture()
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
    int width = 0, height = 0, colorChannels = 0;
    GLuint textureID = 0;

    stbi_set_flip_vertically_on_load(true);

    unsigned char* image = stbi_load(filename, &width, &height, &colorChannels, 0);

    if (!image)
    {
        std::cout << "Could not load image: " << filename << std::endl;
        return false;
    }

    std::cout << "Successfully loaded image:" << filename
        << ", width:" << width
        << ", height:" << height
        << ", channels:" << colorChannels << std::endl;

    glGenTextures(1, &textureID);
    glBindTexture(GL_TEXTURE_2D, textureID);

    // wrap
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

    // filter (mipmaps for quality)
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    if (colorChannels == 3)
    {
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
    }
    else if (colorChannels == 4)
    {
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
    }
    else
    {
        std::cout << "Not implemented to handle image with " << colorChannels << " channels\n";
        stbi_image_free(image);
        glBindTexture(GL_TEXTURE_2D, 0);
        return false;
    }

    glGenerateMipmap(GL_TEXTURE_2D);

    stbi_image_free(image);
    glBindTexture(GL_TEXTURE_2D, 0);

    if (m_loadedTextures >= 16)
    {
        std::cout << "Texture limit reached (16). Could not register: " << filename << std::endl;
        glDeleteTextures(1, &textureID);
        return false;
    }

    m_textureIDs[m_loadedTextures].ID = textureID;
    m_textureIDs[m_loadedTextures].tag = tag;
    m_loadedTextures++;

    return true;
}

/***********************************************************
 *  BindGLTextures()
 ***********************************************************/
void SceneManager::BindGLTextures()
{
    for (int i = 0; i < m_loadedTextures; i++)
    {
        glActiveTexture(GL_TEXTURE0 + i);
        glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
    }
}

/***********************************************************
 *  DestroyGLTextures()
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
    for (int i = 0; i < m_loadedTextures; i++)
    {
        if (m_textureIDs[i].ID != 0)
        {
            glDeleteTextures(1, &m_textureIDs[i].ID);
            m_textureIDs[i].ID = 0;
        }
    }
    m_loadedTextures = 0;
}

/***********************************************************
 *  FindTextureID()
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
    for (int i = 0; i < m_loadedTextures; i++)
    {
        if (m_textureIDs[i].tag.compare(tag) == 0)
            return (int)m_textureIDs[i].ID;
    }
    return -1;
}

/***********************************************************
 *  FindTextureSlot()
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
    for (int i = 0; i < m_loadedTextures; i++)
    {
        if (m_textureIDs[i].tag.compare(tag) == 0)
            return i;
    }
    return -1;
}

/***********************************************************
 *  FindMaterial()
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
    if (m_objectMaterials.empty())
        return false;

    for (size_t i = 0; i < m_objectMaterials.size(); i++)
    {
        if (m_objectMaterials[i].tag == tag)
        {
            material = m_objectMaterials[i];
            return true;
        }
    }
    return false;
}

/***********************************************************
 *  LoadSceneTextures()
 ***********************************************************/
void SceneManager::LoadSceneTextures()
{
    // Put images in: <project>/textures/
    // Ensure they're copied to output folders: Debug/textures and Release/textures.

    CreateGLTexture("textures/base.jpg", "laptopBase");
    CreateGLTexture("textures/screen laptop.jpg", "laptopScreen");

    CreateGLTexture("textures/table base .jpg", "tableTop");
    CreateGLTexture("textures/table legs.jpg", "tableLegs");

    CreateGLTexture("textures/lamp base and stem.jpg", "lampMetal");
    CreateGLTexture("textures/light.jpg", "lampShade");

    // OPTIONAL (only if you add files):
    // CreateGLTexture("textures/monitor_screen.jpg", "monitorScreen");
    // CreateGLTexture("textures/keyboard.jpg", "keyboardTex");

    BindGLTextures();
}

/***********************************************************
 *  DefineObjectMaterials()
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
    m_objectMaterials.clear();

    // Reflective-ish plane
    OBJECT_MATERIAL floor;
    floor.tag = "floor";
    floor.diffuseColor = glm::vec3(1.0f, 1.0f, 1.0f);
    floor.specularColor = glm::vec3(0.40f, 0.40f, 0.40f);
    floor.shininess = 48.0f;
    m_objectMaterials.push_back(floor);

    // Matte wood (table)
    OBJECT_MATERIAL wood;
    wood.tag = "wood";
    wood.diffuseColor = glm::vec3(1.0f, 1.0f, 1.0f);
    wood.specularColor = glm::vec3(0.08f, 0.08f, 0.08f);
    wood.shininess = 8.0f;
    m_objectMaterials.push_back(wood);

    // Metal (lamp/monitor stands)
    OBJECT_MATERIAL metal;
    metal.tag = "metal";
    metal.diffuseColor = glm::vec3(1.0f, 1.0f, 1.0f);
    metal.specularColor = glm::vec3(0.70f, 0.70f, 0.70f);
    metal.shininess = 96.0f;
    m_objectMaterials.push_back(metal);

    // Plastic (laptop/monitors/keyboard)
    OBJECT_MATERIAL plastic;
    plastic.tag = "plastic";
    plastic.diffuseColor = glm::vec3(1.0f, 1.0f, 1.0f);
    plastic.specularColor = glm::vec3(0.35f, 0.35f, 0.35f);
    plastic.shininess = 64.0f;
    m_objectMaterials.push_back(plastic);

    // Shade
    OBJECT_MATERIAL shade;
    shade.tag = "shade";
    shade.diffuseColor = glm::vec3(1.0f, 1.0f, 1.0f);
    shade.specularColor = glm::vec3(0.05f, 0.05f, 0.05f);
    shade.shininess = 4.0f;
    m_objectMaterials.push_back(shade);
}

/***********************************************************
 *  SetupSceneLights()
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
    if (m_pShaderManager == NULL)
        return;

    // IMPORTANT: turn lighting ON in shader
    m_pShaderManager->setBoolValue(g_UseLightingName, true);

    // Turn OFF directional + spotlight (we’ll use 2 point lights)
    m_pShaderManager->setBoolValue("directionalLight.bActive", false);
    m_pShaderManager->setBoolValue("spotLight.bActive", false);

    // Disable all point lights first
    for (int i = 0; i < 5; i++)
    {
        std::string base = "pointLights[" + std::to_string(i) + "].";
        m_pShaderManager->setBoolValue(base + "bActive", false);
    }

    // Point Light 0: "Lamp bulb" (warm / colored)
    {
        std::string L = "pointLights[0].";
        m_pShaderManager->setBoolValue(L + "bActive", true);

        m_pShaderManager->setVec3Value(L + "position", glm::vec3(-3.0f, 5.6f, -1.8f));

        m_pShaderManager->setVec3Value(L + "ambient", glm::vec3(0.08f, 0.07f, 0.05f));
        m_pShaderManager->setVec3Value(L + "diffuse", glm::vec3(1.00f, 0.88f, 0.70f));
        m_pShaderManager->setVec3Value(L + "specular", glm::vec3(1.00f, 0.95f, 0.85f));
    }

    // Point Light 1: Fill light (cool) to prevent full shadows
    {
        std::string L = "pointLights[1].";
        m_pShaderManager->setBoolValue(L + "bActive", true);

        m_pShaderManager->setVec3Value(L + "position", glm::vec3(7.5f, 8.5f, 6.0f));

        m_pShaderManager->setVec3Value(L + "ambient", glm::vec3(0.06f, 0.06f, 0.08f));
        m_pShaderManager->setVec3Value(L + "diffuse", glm::vec3(0.55f, 0.60f, 0.75f));
        m_pShaderManager->setVec3Value(L + "specular", glm::vec3(0.40f, 0.45f, 0.55f));
    }

    // NOTE: Your shader does NOT attenuate point lights, so keep intensities moderate.
}

/***********************************************************
 *  SetTransformations()
 ***********************************************************/
void SceneManager::SetTransformations(
    glm::vec3 scaleXYZ,
    float XrotationDegrees,
    float YrotationDegrees,
    float ZrotationDegrees,
    glm::vec3 positionXYZ,
    glm::vec3 offset)
{
    glm::mat4 scale = glm::scale(scaleXYZ);
    glm::mat4 rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1, 0, 0));
    glm::mat4 rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0, 1, 0));
    glm::mat4 rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0, 0, 1));
    glm::mat4 translation = glm::translate(positionXYZ + offset);

    glm::mat4 model = translation * rotationZ * rotationY * rotationX * scale;

    if (m_pShaderManager != NULL)
        m_pShaderManager->setMat4Value(g_ModelName, model);
}

/***********************************************************
 *  SetShaderColor()
 ***********************************************************/
void SceneManager::SetShaderColor(float r, float g, float b, float a)
{
    if (m_pShaderManager == NULL) return;

    m_pShaderManager->setIntValue(g_UseTextureName, false);
    m_pShaderManager->setVec4Value(g_ColorValueName, glm::vec4(r, g, b, a));
}

/***********************************************************
 *  SetShaderTexture()
 ***********************************************************/
void SceneManager::SetShaderTexture(std::string textureTag)
{
    if (m_pShaderManager == NULL) return;

    int slot = FindTextureSlot(textureTag);
    if (slot < 0)
    {
        // fallback to color mode if tag is wrong
        m_pShaderManager->setIntValue(g_UseTextureName, false);
        return;
    }

    m_pShaderManager->setIntValue(g_UseTextureName, true);
    m_pShaderManager->setSampler2DValue(g_TextureValueName, slot);
}

/***********************************************************
 *  SetTextureUVScale()
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
    if (m_pShaderManager == NULL) return;
    m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
}

/***********************************************************
 *  SetShaderMaterial()
 ***********************************************************/
void SceneManager::SetShaderMaterial(std::string materialTag)
{
    if (m_pShaderManager == NULL) return;

    OBJECT_MATERIAL mat;
    if (FindMaterial(materialTag, mat))
    {
        m_pShaderManager->setVec3Value("material.diffuseColor", mat.diffuseColor);
        m_pShaderManager->setVec3Value("material.specularColor", mat.specularColor);
        m_pShaderManager->setFloatValue("material.shininess", mat.shininess);
    }
}

/***********************************************************
 *  PrepareScene()
 ***********************************************************/
void SceneManager::PrepareScene()
{
    LoadSceneTextures();
    DefineObjectMaterials();
    SetupSceneLights();

    m_basicMeshes->LoadPlaneMesh();
    m_basicMeshes->LoadBoxMesh();
    m_basicMeshes->LoadCylinderMesh();
    m_basicMeshes->LoadConeMesh();
}

/***********************************************************
 *  RenderScene()
 ***********************************************************/
void SceneManager::RenderScene()
{
    glm::vec3 scaleXYZ;
    glm::vec3 positionXYZ;

    // ============================================================
    // BASE PLANE (bigger so it frames the wider desk scene)
    // ============================================================
    scaleXYZ = glm::vec3(16.0f, 1.0f, 14.0f);
    positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

    SetTransformations(scaleXYZ, 0, 0, 0, positionXYZ);
    SetShaderMaterial("floor");
    SetShaderTexture("tableTop");
    SetTextureUVScale(8.0f, 7.0f);
    m_basicMeshes->DrawPlaneMesh();

    // ============================================================
    // TABLETOP (expanded to fit 2 monitors + laptop + keyboard)
    // ============================================================
    scaleXYZ = glm::vec3(12.0f, 0.4f, 6.0f);
    positionXYZ = glm::vec3(0.0f, 2.0f, 0.0f);

    SetTransformations(scaleXYZ, 0, 0, 0, positionXYZ);
    SetShaderMaterial("wood");
    SetShaderTexture("tableTop");
    SetTextureUVScale(4.0f, 2.5f);
    m_basicMeshes->DrawBoxMesh();

    // ============================================================
    // TABLE LEGS (push outward to match new tabletop size)
    // ============================================================
    glm::vec3 legScale(0.25f, 1.7f, 0.25f);

    float tableCenterY = 2.0f;
    float tableHalfThickness = 0.4f / 2.0f;
    float tableBottomY = tableCenterY - tableHalfThickness;
    float legCenterY = tableBottomY - (legScale.y / 2.0f);

    float legX = 5.4f;   // wider
    float legZ = 2.6f;   // deeper

    SetShaderMaterial("wood");
    SetShaderTexture("tableLegs");
    SetTextureUVScale(1.0f, 1.0f);

    SetTransformations(legScale, 0, 0, 0, glm::vec3(-legX, legCenterY, legZ)); m_basicMeshes->DrawBoxMesh();
    SetTransformations(legScale, 0, 0, 0, glm::vec3(legX, legCenterY, legZ)); m_basicMeshes->DrawBoxMesh();
    SetTransformations(legScale, 0, 0, 0, glm::vec3(-legX, legCenterY, -legZ)); m_basicMeshes->DrawBoxMesh();
    SetTransformations(legScale, 0, 0, 0, glm::vec3(legX, legCenterY, -legZ)); m_basicMeshes->DrawBoxMesh();

    // ============================================================
    // LAMP (left side, keep as-is)
    // ============================================================
    // base
    scaleXYZ = glm::vec3(0.9f, 0.25f, 0.9f);
    positionXYZ = glm::vec3(-4.8f, 2.28f, -1.0f);

    SetTransformations(scaleXYZ, 0, 0, 0, positionXYZ);
    SetShaderMaterial("metal");
    SetShaderTexture("lampMetal");
    SetTextureUVScale(1.0f, 1.0f);
    m_basicMeshes->DrawCylinderMesh();

    // stem
    scaleXYZ = glm::vec3(0.15f, 2.5f, 0.15f);
    positionXYZ = glm::vec3(-4.8f, 2.50f, -1.0f);

    SetTransformations(scaleXYZ, 0, 0, 0, positionXYZ);
    SetShaderMaterial("metal");
    SetShaderTexture("lampMetal");
    SetTextureUVScale(1.0f, 2.0f);
    m_basicMeshes->DrawCylinderMesh();

    // shade
    scaleXYZ = glm::vec3(0.9f, 1.0f, 0.9f);
    positionXYZ = glm::vec3(-4.8f, 5.90f, -1.0f);

    SetTransformations(scaleXYZ, 180.0f, 0, 0, positionXYZ);
    SetShaderMaterial("shade");
    SetShaderTexture("lampShade");
    SetTextureUVScale(1.0f, 1.0f);
    m_basicMeshes->DrawConeMesh();

    // ============================================================
    // TWO DESKTOP MONITORS (side-by-side, behind laptop)
    // Each monitor = screen (box) + stand stem (cylinder) + base (box)
    // ============================================================
    const float monitorZ = -2.2f;
    const float monitorY = 4.55f;
    const float standStemY = 1.85f;
    const float standBaseY = 2.30f;

    glm::vec3 monitorScreenScale(4.3f, 2.4f, 0.18f);
    glm::vec3 standStemScale(0.15f, 1.5f, 0.10f);
    glm::vec3 standBaseScale(1.6f, 0.12f, 1.0f);

    // reuse laptop screen texture for both monitors (no new files needed)
    SetShaderMaterial("plastic");
    SetShaderTexture("laptopScreen");
    SetTextureUVScale(1.0f, 1.0f);

    // Left monitor screen
    SetTransformations(monitorScreenScale, 0, 0, 0, glm::vec3(-2.9f, monitorY, monitorZ));
    m_basicMeshes->DrawBoxMesh();

    // Right monitor screen
    SetTransformations(monitorScreenScale, 0, 0, 0, glm::vec3(2.9f, monitorY, monitorZ));
    m_basicMeshes->DrawBoxMesh();

    // Stands: use metal texture
    SetShaderMaterial("metal");
    SetShaderTexture("lampMetal");
    SetTextureUVScale(1.0f, 1.0f);

    // Left stand stem
    SetTransformations(standStemScale, 0, 0, 0, glm::vec3(-2.9f, standStemY, monitorZ));
    m_basicMeshes->DrawCylinderMesh();

    // Right stand stem
    SetTransformations(standStemScale, 0, 0, 0, glm::vec3(2.9f, standStemY, monitorZ));
    m_basicMeshes->DrawCylinderMesh();

    // Left stand base
    SetTransformations(standBaseScale, 0, 0, 0, glm::vec3(-2.9f, standBaseY, monitorZ));
    m_basicMeshes->DrawBoxMesh();

    // Right stand base
    SetTransformations(standBaseScale, 0, 0, 0, glm::vec3(2.9f, standBaseY, monitorZ));
    m_basicMeshes->DrawBoxMesh();

    // ============================================================
    // LAPTOP 
    // ============================================================
    // base
    scaleXYZ = glm::vec3(3.5f, 0.15f, 1.9f);
    positionXYZ = glm::vec3(0.2f, 2.28f, -0.25f);

    SetTransformations(scaleXYZ, 0, 0, 0, positionXYZ);
    SetShaderMaterial("plastic");
    SetShaderTexture("laptopBase");
    SetTextureUVScale(1.0f, 1.0f);
    m_basicMeshes->DrawBoxMesh();

    // screen
    scaleXYZ = glm::vec3(3.5f, 2.2f, 0.12f);
    positionXYZ = glm::vec3(0.2f, 3.33f, -1.5f);

    SetTransformations(scaleXYZ, -15.0f, 0, 0, positionXYZ);
    SetShaderMaterial("plastic");
    SetShaderTexture("laptopScreen");
    SetTextureUVScale(1.0f, 1.0f);
    m_basicMeshes->DrawBoxMesh();

    // ============================================================
    // KEYBOARD (thin box) + MOUSE (small box)
    // ============================================================
    // keyboard
    scaleXYZ = glm::vec3(5.6f, 0.12f, 1.6f);
    positionXYZ = glm::vec3(0.0f, 2.24f, 2.0f);

    SetTransformations(scaleXYZ, 0, 0, 0, positionXYZ);
    SetShaderMaterial("plastic");
    SetShaderColor(0.08f, 0.08f, 0.09f, 1.0f);  // dark keyboard
    m_basicMeshes->DrawBoxMesh();

    // mouse
    scaleXYZ = glm::vec3(0.55f, 0.18f, 0.85f);
    positionXYZ = glm::vec3(4.7f, 2.23f, 2.0f);

    SetTransformations(scaleXYZ, 0, 0, 0, positionXYZ);
    SetShaderMaterial("plastic");
    SetShaderColor(0.10f, 0.10f, 0.11f, 1.0f);  // dark mouse
    m_basicMeshes->DrawBoxMesh();
}
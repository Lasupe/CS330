///////////////////////////////////////////////////////////////////////////////
// scenemanager.h
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//  Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#pragma once

#include "ShaderManager.h"
#include "ShapeMeshes.h"

#include <string>
#include <vector>

class SceneManager
{
public:
    SceneManager(ShaderManager* pShaderManager);
    ~SceneManager();

    struct TEXTURE_INFO
    {
        std::string tag = "/0";
        uint32_t ID = 0; // init to avoid warnings
    };

    struct OBJECT_MATERIAL
    {
        glm::vec3 diffuseColor;
        glm::vec3 specularColor;
        float shininess;
        std::string tag;
    };

private:
    ShaderManager* m_pShaderManager;
    ShapeMeshes* m_basicMeshes;

    int m_loadedTextures;
    TEXTURE_INFO m_textureIDs[16];

    std::vector<OBJECT_MATERIAL> m_objectMaterials;

    // textures
    bool CreateGLTexture(const char* filename, std::string tag);
    void BindGLTextures();
    void DestroyGLTextures();
    int FindTextureID(std::string tag);
    int FindTextureSlot(std::string tag);
    void LoadSceneTextures();

    // materials
    bool FindMaterial(std::string tag, OBJECT_MATERIAL& material);
    void DefineObjectMaterials();

    // lighting
    void SetupSceneLights();

    // transforms / shader helpers
    void SetTransformations(
        glm::vec3 scaleXYZ,
        float XrotationDegrees,
        float YrotationDegrees,
        float ZrotationDegrees,
        glm::vec3 positionXYZ,
        glm::vec3 offset = glm::vec3(0.0f, 0.0f, 0.0f));

    void SetShaderColor(float r, float g, float b, float a);
    void SetShaderTexture(std::string textureTag);
    void SetTextureUVScale(float u, float v);
    void SetShaderMaterial(std::string materialTag);

public:
    void PrepareScene();
    void RenderScene();
};
